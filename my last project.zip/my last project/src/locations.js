export const allLocation = [{
  location: {
    lat: 39.956623,
    lng: -75.189933
  },
  title: 'Drexel University',
  address: 'Lancaster Walk, Philadelphia, PA 19104, USA',
},
{
  location: {
    lat: 39.952220,
    lng: -75.193204
  },
  title: 'University of Pennsylvania',
  address: '3405 Woodland Walk, Philadelphia, PA 19104, USA'
},
{
  location: {
    lat: 39.948890,
    lng: -75.155950
  },
  title: 'Jefferson University',
  address: '130 S 9th St, Philadelphia, PA 19107, USA'
},
{
  location: {
    lat: 39.946821,
    lng: -75.207095
  },
  title: 'University of the Sciences in Philadelphia',
  address: '4217-4231 Woodland Ave, Philadelphia, PA 19104, USA'
},
{
  location: {
    lat: 40.005195,
    lng: -75.216562
  },
  title: 'Philadelphia College of Osteopathic Medicine',
  address: 'Evans Hall, Philadelphia, PA 19131, USA'
},
{
  location: {
    lat: 39.994996,
    lng: -75.240123
  },
  title: 'Saint Joseph\'s University',
  address: '5600 City Ave, Philadelphia, PA 19131, USA'
},
{
  location: {
    lat: 39.981194,
    lng: -75.155353
  },
  title: 'Temple University',
  address: '1801 N Broad St, Philadelphia, PA 19122, USA'
},
{
  location: {
    lat: 40.038608,
    lng: -75.156632
  },
  title: 'La Salle University',
  address: 'Logan/ Ogontz/ Fern Rock, Philadelphia, PA, USA'
}
];